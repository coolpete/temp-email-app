# 10-Minute Temp Email App ⏱️📧

A fast, private, and disposable email generator. Perfect for sign-ups, verifications, and avoiding spam. Emails self-destruct in 10 minutes and refresh automatically.

## 🔧 Features
- One-click generation of a 10-minute email
- Live inbox message fetch
- Auto-refresh after expiration
- Local storage persistence
- Copy-to-clipboard & inbox refresh
- Built-in ad/affiliate placeholders

## 🧰 Built With
- [HTML/CSS/JS](https://developer.mozilla.org/)
- [TailwindCSS](https://tailwindcss.com/)
- [mail.tm API](https://docs.mail.tm)

## 💸 Monetization
- Insert Google AdSense, affiliate banners, or direct sponsor offers
- Example: NordVPN affiliate banner & link included

## 📡 Live Demo
[Click here to view the app](https://coolpete.github.io/temp-email/)

## 🪪 License
[MIT License](LICENSE)

---

> 🔐 **Disclaimer**: For temporary, non-critical use only. Do not use for sensitive or secure email communications.
